/**
 * Capa: Utilidades compartidas
 * Descripción: Gestión de sesión en localStorage y helpers de formato/seguridad.
 *
 * Conexiones:
 *   - Usado por: api/http.js, router/router.js, controllers, components/Sidebar.js, ProgressBar.js
 *   - Claves localStorage: pi_token, pi_user
 *
 * Notas:
 *   - isAuthenticated() solo comprueba token; no valida expiración.
 *   - escapeHtml() obligatorio al renderizar datos de API en innerHTML.
 */
const TOKEN_KEY = 'pi_token'
const USER_KEY = 'pi_user'

export function saveSession(token, user) {
  localStorage.setItem(TOKEN_KEY, token)
  localStorage.setItem(USER_KEY, JSON.stringify(user))
}

export function clearSession() {
  localStorage.removeItem(TOKEN_KEY)
  localStorage.removeItem(USER_KEY)
}

export function getToken() {
  return localStorage.getItem(TOKEN_KEY)
}

export function getUser() {
  const raw = localStorage.getItem(USER_KEY)
  if (!raw) return null
  try {
    return JSON.parse(raw)
  } catch {
    return null
  }
}

export function isAuthenticated() {
  return Boolean(getToken())
}

export function formatPercent(value) {
  const num = Number(value)
  if (Number.isNaN(num)) return '0%'
  return `${Math.min(100, Math.max(0, Math.round(num)))}%`
}

export function escapeHtml(text) {
  return String(text)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;')
}