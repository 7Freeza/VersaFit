/**
 * Capa: Vista (presentación)
 * Descripción: Gestión de hábitos de productividad.
 *
 * Conexiones:
 *   - Importa: Sidebar.js (AppShell)
 *   - Ruta SPA: /productividad
 *   - Controller: controllers/productivity.controller.js
 *
 * IDs HTML: #add-habit-btn, #habits-list
 *
 * Notas:
 *   - Lista vacía inicial con estado de carga.
 */
import { AppShell } from '@/components/Sidebar.js'

export function productivityView() {
  const content = `
    <section class="mx-auto max-w-5xl space-y-6">
      <header class="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 class="text-2xl font-bold text-slate-900">Productividad</h1>
          <p class="mt-1 text-sm text-slate-500">Gestiona hábitos y tareas de disciplina</p>
        </div>
        <button id="add-habit-btn" type="button" class="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700">
          + Nuevo hábito
        </button>
      </header>

      <div id="habits-list" class="grid gap-3">
        <p class="rounded-xl border border-dashed border-slate-300 bg-white p-6 text-center text-sm text-slate-500">
          Cargando hábitos...
        </p>
      </div>
    </section>
  `

  return AppShell({ activePath: '/productividad', content })
}