/**
 * Capa: Vista (presentación)
 * Descripción: Página 404 para rutas SPA no registradas.
 *
 * Conexiones:
 *   - Usada por: router/router.js cuando findRoute() no encuentra coincidencia
 *   - Enlace: /dashboard (data-link)
 *
 * Notas:
 *   - No tiene controller asociado.
 *   - Vista pública sin AppShell.
 */
export function notFoundView() {
  return `
    <section class="flex min-h-screen flex-col items-center justify-center gap-4 bg-slate-50 p-6 text-center">
      <p class="text-6xl font-bold text-slate-300">404</p>
      <h1 class="text-2xl font-semibold text-slate-900">Página no encontrada</h1>
      <p class="max-w-md text-sm text-slate-500">La ruta que buscas no existe en esta aplicación.</p>
      <a href="/dashboard" data-link class="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700">
        Volver al dashboard
      </a>
    </section>
  `
}