/**
 * Capa: Vista (presentación)
 * Descripción: Pantalla de inicio de sesión. Solo devuelve HTML estático.
 *
 * Conexiones:
 *   - Registrada en: router/router.js → ruta /login
 *   - Controller: controllers/login.controller.js
 *
 * IDs HTML: #login-form, #email, #password
 *
 * Notas:
 *   - Sin AppShell; vista pública a pantalla completa.
 *   - Credenciales demo mostradas en la UI.
 */
export function loginView() {
  return `
    <section class="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-900 p-4">
      <div class="w-full max-w-md rounded-2xl bg-white p-8 shadow-2xl">
        <div class="mb-6 text-center">
          <p class="text-xs font-semibold uppercase tracking-wider text-emerald-600">Proyecto Integrador</p>
          <h1 class="mt-2 text-2xl font-bold text-slate-900">Salud, disciplina y productividad</h1>
          <p class="mt-2 text-sm text-slate-500">Inicia sesión para continuar</p>
        </div>

        <form id="login-form" class="space-y-4">
          <div>
            <label for="email" class="mb-1 block text-sm font-medium text-slate-700">Correo</label>
            <input
              id="email"
              name="email"
              type="email"
              required
              placeholder="usuario@ejemplo.com"
              class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none ring-emerald-500 focus:ring-2"
            />
          </div>
          <div>
            <label for="password" class="mb-1 block text-sm font-medium text-slate-700">Contraseña</label>
            <input
              id="password"
              name="password"
              type="password"
              required
              placeholder="••••••••"
              class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none ring-emerald-500 focus:ring-2"
            />
          </div>
          <button
            type="submit"
            class="w-full rounded-lg bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-emerald-700"
          >
            Entrar
          </button>
        </form>

        <p class="mt-4 text-center text-xs text-slate-500">
          Demo: <code class="rounded bg-slate-100 px-1 py-0.5">demo@proyecto.com</code> / <code class="rounded bg-slate-100 px-1 py-0.5">demo123</code>
        </p>
      </div>
    </section>
  `
}