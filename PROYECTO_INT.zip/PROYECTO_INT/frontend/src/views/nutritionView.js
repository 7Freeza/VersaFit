/**
 * Capa: Vista (presentación)
 * Descripción: Plan alimenticio del día y formulario de registro de comidas.
 *
 * Conexiones:
 *   - Importa: Sidebar.js (AppShell)
 *   - Ruta SPA: /nutricion
 *   - Controller: controllers/nutrition.controller.js
 *
 * IDs HTML: #meal-plan, #meal-form (campos: nombre, calorias)
 *
 * Notas:
 *   - Layout en dos columnas en pantallas lg+.
 */
import { AppShell } from '@/components/Sidebar.js'

export function nutritionView() {
  const content = `
    <section class="mx-auto max-w-5xl space-y-6">
      <header>
        <h1 class="text-2xl font-bold text-slate-900">Nutrición</h1>
        <p class="mt-1 text-sm text-slate-500">Plan alimenticio y registro de comidas</p>
      </header>

      <div class="grid gap-4 lg:grid-cols-2">
        <article class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <h2 class="font-semibold text-slate-900">Plan del día</h2>
          <ul id="meal-plan" class="mt-3 space-y-2 text-sm text-slate-600">
            <li class="rounded-lg bg-slate-50 px-3 py-2">Cargando plan...</li>
          </ul>
        </article>
        <article class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <h2 class="font-semibold text-slate-900">Registrar comida</h2>
          <form id="meal-form" class="mt-3 space-y-3">
            <input name="nombre" required placeholder="Ej: Desayuno proteico" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
            <input name="calorias" type="number" min="0" placeholder="Calorías" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
            <button type="submit" class="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700">Guardar</button>
          </form>
        </article>
      </div>
    </section>
  `

  return AppShell({ activePath: '/nutricion', content })
}