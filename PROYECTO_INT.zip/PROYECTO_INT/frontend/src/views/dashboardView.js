/**
 * Capa: Vista (presentación)
 * Descripción: Dashboard con barras de progreso y accesos rápidos a módulos.
 *
 * Conexiones:
 *   - Importa: Sidebar.js (AppShell), ProgressBar.js
 *   - Ruta SPA: /dashboard
 *   - Controller: controllers/dashboard.controller.js
 *
 * IDs HTML: #progress-container
 *
 * Notas:
 *   - Placeholders "Cargando..."; datos reales los inyecta el controller.
 */
import { AppShell } from '@/components/Sidebar.js'
import { ProgressBar } from '@/components/ProgressBar.js'

export function dashboardView() {
  const content = `
    <section class="mx-auto max-w-6xl space-y-6">
      <header>
        <h1 class="text-2xl font-bold text-slate-900">Dashboard</h1>
        <p class="mt-1 text-sm text-slate-500">Resumen de tu progreso en los tres módulos</p>
      </header>

      <div id="progress-container" class="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        ${ProgressBar({ label: 'Progreso general', value: 0, message: 'Cargando...', color: 'emerald' })}
        ${ProgressBar({ label: 'Productividad', value: 0, message: 'Cargando...', color: 'sky' })}
        ${ProgressBar({ label: 'Nutrición', value: 0, message: 'Cargando...', color: 'amber' })}
        ${ProgressBar({ label: 'Ejercicio', value: 0, message: 'Cargando...', color: 'violet' })}
      </div>

      <div class="grid gap-4 md:grid-cols-3">
        <a href="/productividad" data-link class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm transition hover:border-emerald-300 hover:shadow-md">
          <h2 class="font-semibold text-slate-900">Productividad</h2>
          <p class="mt-1 text-sm text-slate-500">Hábitos, metas y tareas diarias</p>
        </a>
        <a href="/nutricion" data-link class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm transition hover:border-emerald-300 hover:shadow-md">
          <h2 class="font-semibold text-slate-900">Nutrición</h2>
          <p class="mt-1 text-sm text-slate-500">Plan alimenticio y registro de comidas</p>
        </a>
        <a href="/ejercicio" data-link class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm transition hover:border-emerald-300 hover:shadow-md">
          <h2 class="font-semibold text-slate-900">Ejercicio</h2>
          <p class="mt-1 text-sm text-slate-500">Rutinas y sesiones completadas</p>
        </a>
      </div>
    </section>
  `

  return AppShell({ activePath: '/dashboard', content })
}