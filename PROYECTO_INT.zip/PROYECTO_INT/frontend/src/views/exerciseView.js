/**
 * Capa: Vista (presentación)
 * Descripción: Listado de rutinas de ejercicio asignadas al usuario.
 *
 * Conexiones:
 *   - Importa: Sidebar.js (AppShell)
 *   - Ruta SPA: /ejercicio
 *   - Controller: controllers/exercise.controller.js
 *
 * IDs HTML: #routines-list
 *
 * Notas:
 *   - Botones de completar sesión se generan dinámicamente en el controller.
 */
import { AppShell } from '@/components/Sidebar.js'

export function exerciseView() {
  const content = `
    <section class="mx-auto max-w-5xl space-y-6">
      <header>
        <h1 class="text-2xl font-bold text-slate-900">Ejercicio</h1>
        <p class="mt-1 text-sm text-slate-500">Rutinas asignadas según tu perfil</p>
      </header>

      <div id="routines-list" class="grid gap-3">
        <p class="rounded-xl border border-dashed border-slate-300 bg-white p-6 text-center text-sm text-slate-500">
          Cargando rutinas...
        </p>
      </div>
    </section>
  `

  return AppShell({ activePath: '/ejercicio', content })
}