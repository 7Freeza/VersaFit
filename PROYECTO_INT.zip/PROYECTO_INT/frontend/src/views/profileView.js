/**
 * Capa: Vista (presentación)
 * Descripción: Formulario de perfil con datos corporales y objetivo.
 *
 * Conexiones:
 *   - Importa: Sidebar.js (AppShell)
 *   - Ruta SPA: /perfil
 *   - Controller: controllers/profile.controller.js
 *
 * IDs HTML: #profile-form, #nombre, #email, #peso, #altura, #objetivo
 *
 * Notas:
 *   - Objetivos: perder_peso, mantener, ganar_musculo.
 */
import { AppShell } from '@/components/Sidebar.js'

export function profileView() {
  const content = `
    <section class="mx-auto max-w-3xl space-y-6">
      <header>
        <h1 class="text-2xl font-bold text-slate-900">Perfil</h1>
        <p class="mt-1 text-sm text-slate-500">Datos corporales y metas personales</p>
      </header>

      <form id="profile-form" class="space-y-4 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
        <div class="grid gap-4 sm:grid-cols-2">
          <div>
            <label class="mb-1 block text-sm font-medium text-slate-700" for="nombre">Nombre</label>
            <input id="nombre" name="nombre" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
          </div>
          <div>
            <label class="mb-1 block text-sm font-medium text-slate-700" for="email">Correo</label>
            <input id="email" name="email" type="email" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
          </div>
          <div>
            <label class="mb-1 block text-sm font-medium text-slate-700" for="peso">Peso (kg)</label>
            <input id="peso" name="peso" type="number" step="0.1" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
          </div>
          <div>
            <label class="mb-1 block text-sm font-medium text-slate-700" for="altura">Altura (cm)</label>
            <input id="altura" name="altura" type="number" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
          </div>
          <div class="sm:col-span-2">
            <label class="mb-1 block text-sm font-medium text-slate-700" for="objetivo">Objetivo</label>
            <select id="objetivo" name="objetivo" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
              <option value="perder_peso">Perder peso</option>
              <option value="mantener">Mantener</option>
              <option value="ganar_musculo">Ganar músculo</option>
            </select>
          </div>
        </div>
        <button type="submit" class="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700">
          Guardar perfil
        </button>
      </form>
    </section>
  `

  return AppShell({ activePath: '/perfil', content })
}