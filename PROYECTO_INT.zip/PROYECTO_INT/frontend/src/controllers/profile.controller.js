/**
 * Capa: Controller (lógica de vista)
 * Descripción: Carga y guarda perfil del usuario (datos corporales y objetivo).
 *
 * Conexiones:
 *   - Vista: views/profileView.js
 *   - API directa: api/http.js (GET/PUT /users/profile)
 *   - Servicio: auth.service.js (logout) | Utils: getUser
 *
 * IDs: #profile-form
 * Endpoints: GET /users/profile, PUT /users/profile
 *
 * Notas:
 *   - Precarga desde localStorage (getUser) antes de fetch al servidor.
 */
import { bindSidebar } from '@/components/Sidebar.js'
import { http } from '@/api/http.js'
import { getUser, clearSession } from '@/utils.js'
import { showToast } from '@/components/Toast.js'
import { navigate } from '@/router/router.js'
import { logout } from '@/services/auth.service.js'

export function mountProfileController(root) {
  bindSidebar(root)
  bindLogout(root)
  loadProfile(root)

  root.querySelector('#profile-form')?.addEventListener('submit', async (event) => {
    event.preventDefault()
    const form = event.currentTarget
    const formData = new FormData(form)

    try {
      await http.put('/users/profile', {
        nombre: formData.get('nombre'),
        email: formData.get('email'),
        peso: Number(formData.get('peso')) || null,
        altura: Number(formData.get('altura')) || null,
        objetivo: formData.get('objetivo'),
      })
      showToast('Perfil actualizado', 'success')
    } catch (error) {
      showToast(error.message, 'error')
    }
  })
}

function bindLogout(root) {
  root.querySelector('#logout-btn')?.addEventListener('click', async () => {
    try { await logout() } catch { /* noop */ }
    clearSession()
    navigate('/login')
  })
}

async function loadProfile(root) {
  const form = root.querySelector('#profile-form')
  if (!form) return

  const cached = getUser()
  if (cached) {
    form.nombre.value = cached.nombre || ''
    form.email.value = cached.email || ''
  }

  try {
    const profile = await http.get('/users/profile')
    form.nombre.value = profile.nombre || ''
    form.email.value = profile.email || ''
    form.peso.value = profile.peso ?? ''
    form.altura.value = profile.altura ?? ''
    form.objetivo.value = profile.objetivo || 'mantener'
  } catch (error) {
    showToast(error.message, 'error')
  }
}