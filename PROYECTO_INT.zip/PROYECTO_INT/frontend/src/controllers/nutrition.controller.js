/**
 * Capa: Controller (lógica de vista)
 * Descripción: Carga plan de comidas y registra nuevas comidas.
 *
 * Conexiones:
 *   - Vista: views/nutritionView.js
 *   - Servicio: nutrition.service.js
 *   - Componentes: Sidebar, Toast | Utils: escapeHtml
 *
 * IDs: #meal-plan, #meal-form
 * Endpoints: GET /nutrition/plan, POST /nutrition/meals
 *
 * Notas:
 *   - Tras registrar, resetea el formulario y recarga el plan.
 */
import { bindSidebar } from '@/components/Sidebar.js'
import { getMealPlan, registerMeal } from '@/services/nutrition.service.js'
import { showToast } from '@/components/Toast.js'
import { escapeHtml } from '@/utils.js'
import { clearSession } from '@/utils.js'
import { navigate } from '@/router/router.js'
import { logout } from '@/services/auth.service.js'

export function mountNutritionController(root) {
  bindSidebar(root)
  bindLogout(root)
  loadPlan(root)

  root.querySelector('#meal-form')?.addEventListener('submit', async (event) => {
    event.preventDefault()
    const form = event.currentTarget
    const formData = new FormData(form)

    try {
      await registerMeal({
        nombre: formData.get('nombre'),
        calorias: Number(formData.get('calorias')) || 0,
      })
      form.reset()
      showToast('Comida registrada', 'success')
      loadPlan(root)
    } catch (error) {
      showToast(error.message, 'error')
    }
  })
}

function bindLogout(root) {
  root.querySelector('#logout-btn')?.addEventListener('click', async () => {
    try { await logout() } catch { /* noop */ }
    clearSession()
    navigate('/login')
  })
}

async function loadPlan(root) {
  const plan = root.querySelector('#meal-plan')
  if (!plan) return

  try {
    const meals = await getMealPlan()
    plan.innerHTML = meals.map((meal) => `
      <li class="rounded-lg bg-slate-50 px-3 py-2">
        <span class="font-medium text-slate-800">${escapeHtml(meal.nombre)}</span>
        <span class="text-slate-500"> — ${meal.calorias} kcal</span>
      </li>
    `).join('')
  } catch (error) {
    showToast(error.message, 'error')
  }
}