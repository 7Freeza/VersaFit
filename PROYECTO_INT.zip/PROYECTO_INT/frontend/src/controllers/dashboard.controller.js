/**
 * Capa: Controller (lógica de vista)
 * Descripción: Carga progreso del dashboard, sidebar y cierre de sesión.
 *
 * Conexiones:
 *   - Vista: views/dashboardView.js
 *   - Servicios: progress.service.js, auth.service.js (logout)
 *   - Componentes: Sidebar, ProgressBar, Toast
 *
 * IDs: #progress-container, #logout-btn
 * Endpoints: GET /progress, POST /auth/logout
 *
 * Notas:
 *   - Reemplaza placeholders de ProgressBar con datos de la API.
 */
import { bindSidebar } from '@/components/Sidebar.js'
import { ProgressBar } from '@/components/ProgressBar.js'
import { getProgressOverview } from '@/services/progress.service.js'
import { clearSession } from '@/utils.js'
import { showToast } from '@/components/Toast.js'
import { navigate } from '@/router/router.js'
import { logout } from '@/services/auth.service.js'

export function mountDashboardController(root) {
  bindSidebar(root)

  root.querySelector('#logout-btn')?.addEventListener('click', async () => {
    try {
      await logout()
    } catch {
      // logout local aunque falle el backend
    }
    clearSession()
    navigate('/login')
  })

  loadProgress(root)
}

async function loadProgress(root) {
  const container = root.querySelector('#progress-container')
  if (!container) return

  try {
    const data = await getProgressOverview()
    container.innerHTML = `
      ${ProgressBar({ label: 'Progreso general', value: data.general, message: data.messages?.general, color: 'emerald' })}
      ${ProgressBar({ label: 'Productividad', value: data.productividad, message: data.messages?.productividad, color: 'sky' })}
      ${ProgressBar({ label: 'Nutrición', value: data.nutricion, message: data.messages?.nutricion, color: 'amber' })}
      ${ProgressBar({ label: 'Ejercicio', value: data.ejercicio, message: data.messages?.ejercicio, color: 'violet' })}
    `
  } catch (error) {
    showToast(error.message, 'error')
  }
}