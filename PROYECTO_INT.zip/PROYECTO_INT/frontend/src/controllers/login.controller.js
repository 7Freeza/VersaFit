/**
 * Capa: Controller (lógica de vista)
 * Descripción: Maneja el envío del formulario de login y redirección post-auth.
 *
 * Conexiones:
 *   - Vista: views/loginView.js
 *   - Servicios: auth.service.js (login)
 *   - Utils: saveSession | Router: navigate
 *   - UI: Toast.js
 *
 * Endpoints: POST /auth/login
 *
 * Notas:
 *   - Guarda token y user en localStorage vía saveSession().
 */
import { login } from '@/services/auth.service.js'
import { saveSession } from '@/utils.js'
import { showToast } from '@/components/Toast.js'
import { navigate } from '@/router/router.js'

export function mountLoginController(root) {
  const form = root.querySelector('#login-form')

  form?.addEventListener('submit', async (event) => {
    event.preventDefault()
    const formData = new FormData(form)

    try {
      const result = await login({
        email: formData.get('email'),
        password: formData.get('password'),
      })

      saveSession(result.token, result.user)
      showToast('Bienvenido de nuevo', 'success')
      navigate('/dashboard')
    } catch (error) {
      showToast(error.message, 'error')
    }
  })
}