/**
 * Capa: Controller (lógica de vista)
 * Descripción: Lista rutinas y permite completar sesiones de ejercicio.
 *
 * Conexiones:
 *   - Vista: views/exerciseView.js
 *   - Servicio: exercise.service.js
 *   - Componentes: Sidebar, Toast | Utils: escapeHtml
 *
 * IDs: #routines-list, [data-session-id]
 * Endpoints: GET /exercise/routines, PATCH /exercise/sessions/:id/complete
 *
 * Notas:
 *   - Botones completados quedan disabled tras marcar sesión.
 */
import { bindSidebar } from '@/components/Sidebar.js'
import { completeSession, getRoutines } from '@/services/exercise.service.js'
import { showToast } from '@/components/Toast.js'
import { escapeHtml } from '@/utils.js'
import { clearSession } from '@/utils.js'
import { navigate } from '@/router/router.js'
import { logout } from '@/services/auth.service.js'

export function mountExerciseController(root) {
  bindSidebar(root)
  bindLogout(root)
  loadRoutines(root)
}

function bindLogout(root) {
  root.querySelector('#logout-btn')?.addEventListener('click', async () => {
    try { await logout() } catch { /* noop */ }
    clearSession()
    navigate('/login')
  })
}

async function loadRoutines(root) {
  const list = root.querySelector('#routines-list')
  if (!list) return

  try {
    const routines = await getRoutines()
    list.innerHTML = routines.map((routine) => `
      <article class="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
        <div class="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 class="font-semibold text-slate-900">${escapeHtml(routine.nombre)}</h3>
            <p class="text-sm text-slate-500">${escapeHtml(routine.descripcion)}</p>
          </div>
          <button
            type="button"
            data-session-id="${routine.id}"
            class="rounded-lg px-3 py-1.5 text-sm font-medium ${routine.completado ? 'bg-emerald-100 text-emerald-700' : 'bg-violet-600 text-white hover:bg-violet-700'}"
            ${routine.completado ? 'disabled' : ''}
          >
            ${routine.completado ? 'Completada' : 'Completar sesión'}
          </button>
        </div>
      </article>
    `).join('')

    list.querySelectorAll('[data-session-id]').forEach((button) => {
      button.addEventListener('click', async () => {
        try {
          await completeSession(button.dataset.sessionId)
          showToast('Sesión completada', 'success')
          loadRoutines(root)
        } catch (error) {
          showToast(error.message, 'error')
        }
      })
    })
  } catch (error) {
    showToast(error.message, 'error')
  }
}