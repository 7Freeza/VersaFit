/**
 * Capa: Controller (lógica de vista)
 * Descripción: CRUD de hábitos: listar, crear (prompt) y marcar completado.
 *
 * Conexiones:
 *   - Vista: views/productivityView.js
 *   - Servicio: productivity.service.js
 *   - Componentes: Sidebar, Toast | Utils: escapeHtml, clearSession
 *
 * IDs: #habits-list, #add-habit-btn, [data-habit-id]
 * Endpoints: GET/POST /productivity/habits, PATCH /productivity/habits/:id/toggle
 *
 * Notas:
 *   - Creación de hábito usa prompt() nativo (provisional).
 */
import { bindSidebar } from '@/components/Sidebar.js'
import { createHabit, getHabits, toggleHabit } from '@/services/productivity.service.js'
import { showToast } from '@/components/Toast.js'
import { escapeHtml, clearSession } from '@/utils.js'
import { navigate } from '@/router/router.js'
import { logout } from '@/services/auth.service.js'

export function mountProductivityController(root) {
  bindSidebar(root)
  bindLogout(root)
  loadHabits(root)

  root.querySelector('#add-habit-btn')?.addEventListener('click', async () => {
    const titulo = prompt('Nombre del hábito:')
    if (!titulo?.trim()) return

    try {
      await createHabit({ titulo: titulo.trim() })
      showToast('Hábito creado', 'success')
      loadHabits(root)
    } catch (error) {
      showToast(error.message, 'error')
    }
  })
}

function bindLogout(root) {
  root.querySelector('#logout-btn')?.addEventListener('click', async () => {
    try { await logout() } catch { /* noop */ }
    clearSession()
    navigate('/login')
  })
}

async function loadHabits(root) {
  const list = root.querySelector('#habits-list')
  if (!list) return

  try {
    const habits = await getHabits()
    if (!habits.length) {
      list.innerHTML = `<p class="rounded-xl border border-dashed border-slate-300 bg-white p-6 text-center text-sm text-slate-500">No hay hábitos aún. Crea el primero.</p>`
      return
    }

    list.innerHTML = habits.map((habit) => `
      <article class="flex items-center justify-between rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
        <div>
          <h3 class="font-medium text-slate-900">${escapeHtml(habit.titulo)}</h3>
          <p class="text-xs text-slate-500">${habit.completado ? 'Completado hoy' : 'Pendiente hoy'}</p>
        </div>
        <button
          type="button"
          data-habit-id="${habit.id}"
          class="rounded-lg px-3 py-1.5 text-sm font-medium ${habit.completado ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-700 hover:bg-emerald-50'}"
        >
          ${habit.completado ? '✓ Hecho' : 'Marcar'}
        </button>
      </article>
    `).join('')

    list.querySelectorAll('[data-habit-id]').forEach((button) => {
      button.addEventListener('click', async () => {
        try {
          await toggleHabit(button.dataset.habitId)
          loadHabits(root)
        } catch (error) {
          showToast(error.message, 'error')
        }
      })
    })
  } catch (error) {
    showToast(error.message, 'error')
  }
}