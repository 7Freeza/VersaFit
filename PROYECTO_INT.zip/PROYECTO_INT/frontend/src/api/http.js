/**
 * Capa: API (cliente HTTP)
 * Descripción: Wrapper de fetch con base URL, JSON y cabecera Authorization Bearer.
 *
 * Conexiones:
 *   - Importa: utils.js (getToken)
 *   - Usado por: todos los services/*.js y profile.controller.js
 *   - Base: VITE_API_URL o /api (proxy Vite en dev)
 *
 * Notas:
 *   - Lanza Error con message del backend en respuestas no-ok.
 *   - Métodos: get, post, put, patch, delete.
 */
import { getToken } from '@/utils.js'

const API_BASE = import.meta.env.VITE_API_URL || '/api'

async function request(path, options = {}) {
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  }

  const token = getToken()
  if (token) {
    headers.Authorization = `Bearer ${token}`
  }

  const response = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers,
  })

  const contentType = response.headers.get('content-type') || ''
  const isJson = contentType.includes('application/json')
  const data = isJson ? await response.json() : await response.text()

  if (!response.ok) {
    const message = typeof data === 'object' && data?.message
      ? data.message
      : 'Error en la petición'
    throw new Error(message)
  }

  return data
}

export const http = {
  get: (path) => request(path),
  post: (path, body) => request(path, { method: 'POST', body: JSON.stringify(body) }),
  put: (path, body) => request(path, { method: 'PUT', body: JSON.stringify(body) }),
  patch: (path, body) => request(path, { method: 'PATCH', body: JSON.stringify(body) }),
  delete: (path) => request(path, { method: 'DELETE' }),
}