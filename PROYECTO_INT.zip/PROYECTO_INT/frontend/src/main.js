/**
 * Capa: Punto de entrada de la aplicación
 * Descripción: Bootstrap mínimo: carga estilos globales e inicializa el router SPA.
 *
 * Conexiones:
 *   - Importa: style.css, router/router.js (initRouter)
 *   - Invocado desde: index.html (<script src="/src/main.js">)
 *
 * Notas:
 *   - Toda la navegación y renderizado pasa por el router.
 *   - No añadir lógica de negocio aquí.
 */
import './style.css'
import { initRouter } from '@/router/router.js'

initRouter()