/**
 * Capa: Componente (UI modal)
 * Descripción: Diálogo de confirmación imperativo montado en #modal-root.
 *
 * Conexiones:
 *   - Monta en: index.html → #modal-root
 *   - IDs generados: #modal-cancel, #modal-confirm
 *
 * Notas:
 *   - API: openModal({ title, body, confirmLabel, onConfirm }).
 *   - Se limpia innerHTML al cerrar; un solo modal a la vez.
 */
export function openModal({ title, body, confirmLabel = 'Confirmar', onConfirm }) {
  const root = document.querySelector('#modal-root')
  if (!root) return

  root.innerHTML = `
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4" role="dialog" aria-modal="true">
      <div class="w-full max-w-md rounded-2xl bg-white p-6 shadow-xl">
        <h2 class="text-lg font-semibold text-slate-900">${title}</h2>
        <div class="mt-3 text-sm text-slate-600">${body}</div>
        <div class="mt-6 flex justify-end gap-2">
          <button type="button" id="modal-cancel" class="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
            Cancelar
          </button>
          <button type="button" id="modal-confirm" class="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700">
            ${confirmLabel}
          </button>
        </div>
      </div>
    </div>
  `

  const close = () => {
    root.innerHTML = ''
  }

  root.querySelector('#modal-cancel')?.addEventListener('click', close)
  root.querySelector('#modal-confirm')?.addEventListener('click', async () => {
    await onConfirm?.()
    close()
  })
}