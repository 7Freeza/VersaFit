/**
 * Capa: Componente (UI)
 * Descripción: Barra de progreso reutilizable con etiqueta, porcentaje y mensaje.
 *
 * Conexiones:
 *   - Importa: utils.js (formatPercent)
 *   - Usado por: views/dashboardView.js, controllers/dashboard.controller.js
 *
 * Notas:
 *   - Colores: emerald, sky, amber, violet.
 *   - value: 0-100; el ancho se calcula con formatPercent().
 */
import { formatPercent } from '@/utils.js'

export function ProgressBar({ label, value, message, color = 'emerald' }) {
  const width = formatPercent(value)
  const colorClass = {
    emerald: 'bg-emerald-500',
    sky: 'bg-sky-500',
    amber: 'bg-amber-500',
    violet: 'bg-violet-500',
  }[color] || 'bg-emerald-500'

  return `
    <div class="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <div class="mb-2 flex items-center justify-between gap-3">
        <h3 class="text-sm font-semibold text-slate-800">${label}</h3>
        <span class="text-sm font-bold text-slate-700">${width}</span>
      </div>
      <div class="h-3 w-full overflow-hidden rounded-full bg-slate-100">
        <div class="${colorClass} h-full rounded-full transition-all duration-500" style="width: ${width}"></div>
      </div>
      ${message ? `<p class="mt-2 text-xs text-slate-500">${message}</p>` : ''}
    </div>
  `
}