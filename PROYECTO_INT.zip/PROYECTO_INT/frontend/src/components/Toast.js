/**
 * Capa: Componente (notificaciones)
 * Descripción: Toasts temporales en la esquina inferior derecha.
 *
 * Conexiones:
 *   - Monta en: index.html → #toast-root
 *   - Usado por: todos los controllers
 *
 * Notas:
 *   - API: showToast(message, type='info', duration=3200).
 *   - Tipos: success, error, info.
 */
const COLORS = {
  success: 'bg-emerald-600',
  error: 'bg-red-600',
  info: 'bg-slate-800',
}

export function showToast(message, type = 'info', duration = 3200) {
  const root = document.querySelector('#toast-root')
  if (!root) return

  const toast = document.createElement('div')
  toast.className = `pointer-events-auto mb-2 rounded-lg px-4 py-3 text-sm font-medium text-white shadow-lg ${COLORS[type] || COLORS.info}`
  toast.textContent = message

  root.appendChild(toast)

  setTimeout(() => {
    toast.remove()
  }, duration)
}