/**
 * Capa: Componente (layout / navegación)
 * Descripción: Sidebar, shell de app autenticada y binding del menú móvil.
 *
 * Conexiones:
 *   - Importa: utils.js (getUser)
 *   - Usado por: views/* (AppShell), controllers/* (bindSidebar)
 *   - Rutas nav: /dashboard, /productividad, /nutricion, /ejercicio, /perfil
 *
 * IDs HTML: #app-sidebar, #sidebar-overlay, #sidebar-toggle, #logout-btn
 *
 * Notas:
 *   - Enlaces con data-link para navegación SPA.
 *   - bindSidebar() debe llamarse en cada controller de vista autenticada.
 */
import { getUser } from '@/utils.js'

const NAV_ITEMS = [
  { href: '/dashboard', label: 'Dashboard', icon: '📊' },
  { href: '/productividad', label: 'Productividad', icon: '✅' },
  { href: '/nutricion', label: 'Nutrición', icon: '🥗' },
  { href: '/ejercicio', label: 'Ejercicio', icon: '💪' },
  { href: '/perfil', label: 'Perfil', icon: '👤' },
]

export function Sidebar({ activePath }) {
  const user = getUser()
  const name = user?.nombre || 'Usuario'

  const links = NAV_ITEMS.map(
    (item) => `
      <a
        href="${item.href}"
        data-link
        class="flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
          activePath === item.href
            ? 'bg-emerald-600 text-white'
            : 'text-slate-300 hover:bg-slate-800 hover:text-white'
        }"
      >
        <span aria-hidden="true">${item.icon}</span>
        <span>${item.label}</span>
      </a>
    `,
  ).join('')

  return `
    <aside class="app-sidebar flex flex-col bg-slate-900 text-white" id="app-sidebar">
      <div class="border-b border-slate-700 px-4 py-5">
        <p class="text-xs uppercase tracking-wider text-slate-400">Proyecto Integrador</p>
        <p class="mt-1 text-lg font-semibold">${name}</p>
      </div>
      <nav class="flex flex-1 flex-col gap-1 p-3" aria-label="Navegación principal">
        ${links}
      </nav>
      <div class="border-t border-slate-700 p-3">
        <button
          type="button"
          id="logout-btn"
          class="w-full rounded-lg border border-slate-600 px-3 py-2 text-sm text-slate-200 transition-colors hover:bg-slate-800"
        >
          Cerrar sesión
        </button>
      </div>
    </aside>
  `
}

export function AppShell({ activePath, content }) {
  return `
    <div class="app-sidebar-overlay" id="sidebar-overlay" aria-hidden="true"></div>
    <div class="app-layout min-h-screen">
      ${Sidebar({ activePath })}
      <div class="flex min-h-screen flex-col">
        <header class="mobile-only sticky top-0 z-20 flex items-center justify-between border-b border-slate-200 bg-white px-4 py-3">
          <button
            type="button"
            id="sidebar-toggle"
            class="rounded-lg border border-slate-200 px-3 py-2 text-sm font-medium text-slate-700"
            aria-label="Abrir menú"
          >
            ☰ Menú
          </button>
          <span class="text-sm font-semibold text-slate-800">Proyecto Integrador</span>
        </header>
        <main class="flex-1 p-4 md:p-6 lg:p-8">
          ${content}
        </main>
      </div>
    </div>
  `
}

export function bindSidebar(root) {
  const sidebar = root.querySelector('#app-sidebar')
  const overlay = root.querySelector('#sidebar-overlay')
  const toggle = root.querySelector('#sidebar-toggle')

  const close = () => {
    sidebar?.classList.remove('is-open')
    overlay?.classList.remove('is-visible')
  }

  const open = () => {
    sidebar?.classList.add('is-open')
    overlay?.classList.add('is-visible')
  }

  toggle?.addEventListener('click', open)
  overlay?.addEventListener('click', close)

  root.querySelectorAll('[data-link]').forEach((link) => {
    link.addEventListener('click', close)
  })
}