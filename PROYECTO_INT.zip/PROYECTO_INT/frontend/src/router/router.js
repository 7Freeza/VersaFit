/**
 * Capa: Router (navegación SPA)
 * Descripción: Enrutamiento por pathname con History API, guards de auth y montaje de controllers.
 *
 * Conexiones:
 *   - Importa: views/*, controllers/*, utils.js (isAuthenticated)
 *   - Exporta: initRouter (main.js), navigate (controllers)
 *   - Monta HTML en: #app
 *
 * Rutas SPA:
 *   /login (pública), /dashboard, /productividad, /nutricion, /ejercicio, /perfil
 *   / → redirige a /dashboard o /login según sesión
 *
 * Notas:
 *   - Enlaces internos deben usar data-link para evitar recarga completa.
 *   - Rutas no definidas muestran notFoundView.
 */
import { isAuthenticated } from '@/utils.js'
import { loginView } from '@/views/loginView.js'
import { dashboardView } from '@/views/dashboardView.js'
import { productivityView } from '@/views/productivityView.js'
import { nutritionView } from '@/views/nutritionView.js'
import { exerciseView } from '@/views/exerciseView.js'
import { profileView } from '@/views/profileView.js'
import { notFoundView } from '@/views/notFound.js'
import { mountLoginController } from '@/controllers/login.controller.js'
import { mountDashboardController } from '@/controllers/dashboard.controller.js'
import { mountProductivityController } from '@/controllers/productivity.controller.js'
import { mountNutritionController } from '@/controllers/nutrition.controller.js'
import { mountExerciseController } from '@/controllers/exercise.controller.js'
import { mountProfileController } from '@/controllers/profile.controller.js'

const routes = [
  { path: '/login', view: loginView, controller: mountLoginController, public: true },
  { path: '/dashboard', view: dashboardView, controller: mountDashboardController },
  { path: '/productividad', view: productivityView, controller: mountProductivityController },
  { path: '/nutricion', view: nutritionView, controller: mountNutritionController },
  { path: '/ejercicio', view: exerciseView, controller: mountExerciseController },
  { path: '/perfil', view: profileView, controller: mountProfileController },
]

function getPath() {
  return window.location.pathname || '/'
}

function findRoute(path) {
  return routes.find((route) => route.path === path)
}

function navigate(path, replace = false) {
  if (replace) {
    history.replaceState({}, '', path)
  } else {
    history.pushState({}, '', path)
  }
  render()
}

function render() {
  const app = document.querySelector('#app')
  const path = getPath()
  const route = findRoute(path)

  if (!route) {
    app.innerHTML = notFoundView()
    return
  }

  if (!route.public && !isAuthenticated()) {
    navigate('/login', true)
    return
  }

  if (route.public && isAuthenticated() && path === '/login') {
    navigate('/dashboard', true)
    return
  }

  app.innerHTML = route.view()
  route.controller?.(app)
}

export function initRouter() {
  window.addEventListener('popstate', render)

  document.addEventListener('click', (event) => {
    const link = event.target.closest('[data-link]')
    if (!link) return
    event.preventDefault()
    navigate(link.getAttribute('href'))
  })

  if (getPath() === '/') {
    navigate(isAuthenticated() ? '/dashboard' : '/login', true)
    return
  }

  render()
}

export { navigate }