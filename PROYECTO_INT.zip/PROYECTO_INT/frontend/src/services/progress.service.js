/**
 * Capa: Servicio (API progreso)
 * Descripción: Obtiene resumen de progreso para el dashboard.
 *
 * Conexiones:
 *   - Cliente: api/http.js
 *   - Usado por: controllers/dashboard.controller.js
 *
 * Endpoint: GET /progress
 *
 * Notas:
 *   - Respuesta esperada: { general, productividad, nutricion, ejercicio, messages? }.
 */
import { http } from '@/api/http.js'

export async function getProgressOverview() {
  return http.get('/progress')
}