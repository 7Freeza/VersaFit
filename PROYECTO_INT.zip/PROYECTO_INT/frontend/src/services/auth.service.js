/**
 * Capa: Servicio (API auth)
 * Descripción: Autenticación: login, registro y logout.
 *
 * Conexiones:
 *   - Cliente: api/http.js
 *   - Usado por: login.controller.js, controllers con logout
 *
 * Endpoints:
 *   - POST /auth/login
 *   - POST /auth/register
 *   - POST /auth/logout
 *
 * Notas:
 *   - register() existe pero no hay vista de registro aún.
 */
import { http } from '@/api/http.js'

export async function login(credentials) {
  return http.post('/auth/login', credentials)
}

export async function register(data) {
  return http.post('/auth/register', data)
}

export async function logout() {
  return http.post('/auth/logout', {})
}