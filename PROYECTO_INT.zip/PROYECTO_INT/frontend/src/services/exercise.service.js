/**
 * Capa: Servicio (API ejercicio)
 * Descripción: Rutinas asignadas y completado de sesiones.
 *
 * Conexiones:
 *   - Cliente: api/http.js
 *   - Usado por: controllers/exercise.controller.js
 *
 * Endpoints:
 *   - GET /exercise/routines
 *   - PATCH /exercise/sessions/:id/complete
 *
 * Notas:
 *   - completeSession marca la sesión/rutina como completada en backend.
 */
import { http } from '@/api/http.js'

export async function getRoutines() {
  return http.get('/exercise/routines')
}

export async function completeSession(id) {
  return http.patch(`/exercise/sessions/${id}/complete`, {})
}