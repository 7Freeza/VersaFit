/**
 * Capa: Servicio (API productividad)
 * Descripción: Operaciones sobre hábitos del módulo de productividad.
 *
 * Conexiones:
 *   - Cliente: api/http.js
 *   - Usado por: controllers/productivity.controller.js
 *
 * Endpoints:
 *   - GET /productivity/habits
 *   - POST /productivity/habits
 *   - PATCH /productivity/habits/:id/toggle
 *
 * Notas:
 *   - toggleHabit alterna estado completado del hábito del día.
 */
import { http } from '@/api/http.js'

export async function getHabits() {
  return http.get('/productivity/habits')
}

export async function createHabit(data) {
  return http.post('/productivity/habits', data)
}

export async function toggleHabit(id) {
  return http.patch(`/productivity/habits/${id}/toggle`, {})
}