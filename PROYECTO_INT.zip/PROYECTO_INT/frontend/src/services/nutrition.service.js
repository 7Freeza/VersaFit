/**
 * Capa: Servicio (API nutrición)
 * Descripción: Plan alimenticio y registro de comidas.
 *
 * Conexiones:
 *   - Cliente: api/http.js
 *   - Usado por: controllers/nutrition.controller.js
 *
 * Endpoints:
 *   - GET /nutrition/plan
 *   - POST /nutrition/meals
 *
 * Notas:
 *   - registerMeal envía { nombre, calorias }.
 */
import { http } from '@/api/http.js'

export async function getMealPlan() {
  return http.get('/nutrition/plan')
}

export async function registerMeal(data) {
  return http.post('/nutrition/meals', data)
}