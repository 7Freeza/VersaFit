/**
 * ARCHIVO: backend/src/middleware/auth.middleware.js
 * CAPA: Middleware
 * CONECTA CON:
 *   - Usado por: users, progress, productivity, nutrition, exercise routes
 *   - Depende de: JWT_SECRET (.env), header Authorization: Bearer <token>
 *   - Token generado en: auth.service.js (login/register)
 * RESPONSABILIDAD: Verificar JWT y adjuntar req.user { id, email, nombre }.
 * ENDPOINTS / TABLAS / DATOS: No aplica; protege rutas bajo /api/* excepto /api/auth.
 * NOTAS: Responde 401 si falta token o es inválido/expirado (8h). No consulta BD.
 */

import jwt from 'jsonwebtoken'

export function authMiddleware(req, res, next) {
  const header = req.headers.authorization || ''
  const token = header.startsWith('Bearer ') ? header.slice(7) : null

  if (!token) {
    return res.status(401).json({ message: 'Token requerido' })
  }

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET || 'dev_secret')
    req.user = { id: payload.id, email: payload.email, nombre: payload.nombre }
    next()
  } catch {
    return res.status(401).json({ message: 'Token inválido o expirado' })
  }
}