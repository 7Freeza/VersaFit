/**
 * ARCHIVO: backend/src/middleware/validate.middleware.js
 * CAPA: Middleware
 * CONECTA CON:
 *   - Usado por: auth.routes, productivity.routes, nutrition.routes
 *   - Exporta: validateBody(campos[])
 * RESPONSABILIDAD: Validar que req.body contenga campos obligatorios no vacíos.
 * ENDPOINTS / TABLAS / DATOS: Aplica antes de controllers en POST/PATCH con body JSON.
 * NOTAS: Responde 400 con lista de campos faltantes. No valida tipos ni formatos (email, etc.).
 */

export function validateBody(requiredFields = []) {
  return (req, res, next) => {
    const missing = requiredFields.filter((field) => {
      const value = req.body?.[field]
      return value === undefined || value === null || value === ''
    })

    if (missing.length) {
      return res.status(400).json({
        message: `Campos requeridos: ${missing.join(', ')}`,
      })
    }

    next()
  }
}