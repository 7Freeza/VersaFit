/**
 * ARCHIVO: backend/src/routes/progress.routes.js
 * CAPA: Rutas
 * CONECTA CON:
 *   - Montado en: server.js → /api/progress
 *   - Usa: progress.controller.js, auth.middleware.js
 * RESPONSABILIDAD: Ruta única de resumen de progreso del usuario.
 * ENDPOINTS / TABLAS / DATOS:
 *   - GET / (prefijo /api/progress)
 * NOTAS: Requiere Bearer token. Sin parámetros de query.
 */

import { Router } from 'express'
import * as progressController from '../controllers/progress.controller.js'
import { authMiddleware } from '../middleware/auth.middleware.js'

const router = Router()

router.use(authMiddleware)
router.get('/', progressController.getProgress)

export default router