/**
 * ARCHIVO: backend/src/routes/productivity.routes.js
 * CAPA: Rutas
 * CONECTA CON:
 *   - Montado en: server.js → /api/productivity
 *   - Usa: productivity.controller.js, auth.middleware.js, validate.middleware.js
 * RESPONSABILIDAD: API de hábitos de productividad del usuario autenticado.
 * ENDPOINTS / TABLAS / DATOS:
 *   - GET /habits, POST /habits, PATCH /habits/:id/toggle (prefijo /api/productivity)
 * NOTAS: POST exige titulo en body. Toggle usa PATCH, no PUT.
 */

import { Router } from 'express'
import * as productivityController from '../controllers/productivity.controller.js'
import { authMiddleware } from '../middleware/auth.middleware.js'
import { validateBody } from '../middleware/validate.middleware.js'

const router = Router()

router.use(authMiddleware)
router.get('/habits', productivityController.listHabits)
router.post('/habits', validateBody(['titulo']), productivityController.createHabit)
router.patch('/habits/:id/toggle', productivityController.toggleHabit)

export default router