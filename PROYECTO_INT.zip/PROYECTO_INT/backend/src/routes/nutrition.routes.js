/**
 * ARCHIVO: backend/src/routes/nutrition.routes.js
 * CAPA: Rutas
 * CONECTA CON:
 *   - Montado en: server.js → /api/nutrition
 *   - Usa: nutrition.controller.js, auth.middleware.js, validate.middleware.js
 * RESPONSABILIDAD: Plan y registro de comidas del día.
 * ENDPOINTS / TABLAS / DATOS:
 *   - GET /plan, POST /meals (prefijo /api/nutrition)
 * NOTAS: POST /meals valida solo nombre; calorias es opcional en servicio.
 */

import { Router } from 'express'
import * as nutritionController from '../controllers/nutrition.controller.js'
import { authMiddleware } from '../middleware/auth.middleware.js'
import { validateBody } from '../middleware/validate.middleware.js'

const router = Router()

router.use(authMiddleware)
router.get('/plan', nutritionController.getPlan)
router.post('/meals', validateBody(['nombre']), nutritionController.registerMeal)

export default router