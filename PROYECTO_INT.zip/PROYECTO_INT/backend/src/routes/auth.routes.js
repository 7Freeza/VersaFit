/**
 * ARCHIVO: backend/src/routes/auth.routes.js
 * CAPA: Rutas
 * CONECTA CON:
 *   - Montado en: server.js → /api/auth
 *   - Usa: auth.controller.js, validate.middleware.js
 * RESPONSABILIDAD: Definir rutas públicas de autenticación (sin JWT).
 * ENDPOINTS / TABLAS / DATOS:
 *   - POST /login, /register, /logout (prefijo /api/auth)
 * NOTAS: login/register validan body. logout no requiere token en esta implementación.
 */

import { Router } from 'express'
import * as authController from '../controllers/auth.controller.js'
import { validateBody } from '../middleware/validate.middleware.js'

const router = Router()

router.post('/login', validateBody(['email', 'password']), authController.login)
router.post('/register', validateBody(['nombre', 'email', 'password']), authController.register)
router.post('/logout', authController.logout)

export default router