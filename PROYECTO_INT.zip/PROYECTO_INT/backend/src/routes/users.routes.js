/**
 * ARCHIVO: backend/src/routes/users.routes.js
 * CAPA: Rutas
 * CONECTA CON:
 *   - Montado en: server.js → /api/users
 *   - Usa: users.controller.js, auth.middleware.js
 * RESPONSABILIDAD: Rutas de perfil protegidas por JWT.
 * ENDPOINTS / TABLAS / DATOS:
 *   - GET /profile, PUT /profile (prefijo /api/users)
 * NOTAS: router.use(authMiddleware) aplica a todas las rutas del router.
 */

import { Router } from 'express'
import * as usersController from '../controllers/users.controller.js'
import { authMiddleware } from '../middleware/auth.middleware.js'

const router = Router()

router.use(authMiddleware)
router.get('/profile', usersController.getProfile)
router.put('/profile', usersController.updateProfile)

export default router