/**
 * ARCHIVO: backend/src/routes/exercise.routes.js
 * CAPA: Rutas
 * CONECTA CON:
 *   - Montado en: server.js → /api/exercise
 *   - Usa: exercise.controller.js, auth.middleware.js
 * RESPONSABILIDAD: Rutinas y marcado de sesión completada.
 * ENDPOINTS / TABLAS / DATOS:
 *   - GET /routines, PATCH /sessions/:id/complete (prefijo /api/exercise)
 * NOTAS: :id en complete es routineId. Sin validateBody en estas rutas.
 */

import { Router } from 'express'
import * as exerciseController from '../controllers/exercise.controller.js'
import { authMiddleware } from '../middleware/auth.middleware.js'

const router = Router()

router.use(authMiddleware)
router.get('/routines', exerciseController.listRoutines)
router.patch('/sessions/:id/complete', exerciseController.completeSession)

export default router