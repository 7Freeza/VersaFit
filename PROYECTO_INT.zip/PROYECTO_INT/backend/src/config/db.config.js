/**
 * ARCHIVO: backend/src/config/db.config.js
 * CAPA: Configuración
 * CONECTA CON:
 *   - Exporta: pool (reexportado en src/models/db.js)
 *   - Variables: .env (DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME)
 *   - Consumido por: models/db.js → todos los modelos y db.helper.js
 * RESPONSABILIDAD: Crear y exportar el pool de conexiones MySQL (mysql2/promise).
 * ENDPOINTS / TABLAS / DATOS: Pool hacia la BD proyecto_integrador; límite 10 conexiones.
 * NOTAS: Único lugar donde se instancia el pool. Sin lógica de consultas SQL aquí.
 */

import mysql from 'mysql2/promise'
import dotenv from 'dotenv'

dotenv.config()

export const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT) || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'proyecto_integrador',
  waitForConnections: true,
  connectionLimit: 10,
})