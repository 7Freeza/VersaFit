/**
 * ARCHIVO: backend/src/services/memory.store.js
 * CAPA: Servicios (datos en memoria / fallback desarrollo)
 * CONECTA CON:
 *   - Exporta: memoryStore (singleton en proceso)
 *   - Usado por: auth, users, progress, productivity, nutrition, exercise services
 * RESPONSABILIDAD: Almacén temporal cuando MySQL no está disponible; datos demo precargados.
 * ENDPOINTS / TABLAS / DATOS:
 *   - users, habits, meals, routines indexados por userId
 *   - Demo: id=1, demo@proyecto.com / demo123
 * NOTAS: Se pierde al reiniciar el servidor. No usar en producción.
 */

import bcrypt from 'bcryptjs'

const demoPassword = bcrypt.hashSync('demo123', 10)

export const memoryStore = {
  users: [
    {
      id: 1,
      nombre: 'Usuario Demo',
      email: 'demo@proyecto.com',
      password_hash: demoPassword,
      peso: 70,
      altura: 175,
      objetivo: 'mantener',
    },
  ],
  habits: {
    1: [
      { id: 1, titulo: 'Leer 20 minutos', completado: false },
      { id: 2, titulo: 'Planificar el día', completado: true },
    ],
  },
  meals: {
    1: [
      { id: 1, nombre: 'Avena con frutas', calorias: 350 },
      { id: 2, nombre: 'Pollo con arroz', calorias: 520 },
    ],
  },
  routines: {
    1: [
      { id: 1, nombre: 'Full body principiante', descripcion: '3 series x 12 repeticiones', completado: false },
      { id: 2, nombre: 'Cardio ligero', descripcion: '20 minutos caminata rápida', completado: true },
    ],
  },
  nextHabitId: 3,
  nextMealId: 3,
}