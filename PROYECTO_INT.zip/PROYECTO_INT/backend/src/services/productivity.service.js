/**
 * ARCHIVO: backend/src/services/productivity.service.js
 * CAPA: Servicios (lógica de negocio)
 * CONECTA CON:
 *   - Llamado por: productivity.controller.js
 *   - Usa: productivity.model.js, db.helper.js, memory.store.js
 * RESPONSABILIDAD: Listar, crear y alternar estado de hábitos del usuario.
 * ENDPOINTS / TABLAS / DATOS:
 *   - GET/POST /api/productivity/habits, PATCH .../habits/:id/toggle
 *   - Tablas habitos / habitos_registro o memoryStore.habits[userId]
 * NOTAS: En memoria, toggle invierte boolean; en BD delega a toggleHabitToday (por fecha).
 */

import * as productivityModel from '../models/productivity.model.js'
import { isDbAvailable } from './db.helper.js'
import { memoryStore } from './memory.store.js'

export async function listHabits(userId) {
  if (await isDbAvailable()) {
    return productivityModel.getHabitsByUser(userId)
  }
  return memoryStore.habits[userId] || []
}

export async function addHabit(userId, titulo) {
  if (await isDbAvailable()) {
    return productivityModel.createHabit(userId, titulo)
  }

  const habit = {
    id: memoryStore.nextHabitId++,
    titulo,
    completado: false,
  }
  if (!memoryStore.habits[userId]) memoryStore.habits[userId] = []
  memoryStore.habits[userId].push(habit)
  return habit
}

export async function toggleHabit(userId, habitId) {
  if (await isDbAvailable()) {
    return productivityModel.toggleHabitToday(userId, habitId)
  }

  const habits = memoryStore.habits[userId] || []
  const habit = habits.find((item) => item.id === Number(habitId))
  if (!habit) {
    const error = new Error('Hábito no encontrado')
    error.status = 404
    throw error
  }
  habit.completado = !habit.completado
  return { completado: habit.completado }
}