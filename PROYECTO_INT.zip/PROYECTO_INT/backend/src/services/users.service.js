/**
 * ARCHIVO: backend/src/services/users.service.js
 * CAPA: Servicios (lógica de negocio)
 * CONECTA CON:
 *   - Llamado por: users.controller.js
 *   - Usa: user.model.js, db.helper.js, memory.store.js
 * RESPONSABILIDAD: Obtener y actualizar perfil del usuario autenticado (sin password).
 * ENDPOINTS / TABLAS / DATOS:
 *   - Campos perfil: nombre, email, peso, altura, objetivo (default 'mantener')
 *   - Tabla usuarios o memoryStore.users
 * NOTAS: sanitize() nunca expone password_hash. 404 si usuario no existe.
 */

import * as userModel from '../models/user.model.js'
import { isDbAvailable } from './db.helper.js'
import { memoryStore } from './memory.store.js'

function sanitize(user) {
  return {
    id: user.id,
    nombre: user.nombre,
    email: user.email,
    peso: user.peso ?? null,
    altura: user.altura ?? null,
    objetivo: user.objetivo ?? 'mantener',
  }
}

export async function getProfile(userId) {
  if (await isDbAvailable()) {
    const user = await userModel.findById(userId)
    if (!user) {
      const error = new Error('Usuario no encontrado')
      error.status = 404
      throw error
    }
    return sanitize(user)
  }

  const user = memoryStore.users.find((item) => item.id === userId)
  if (!user) {
    const error = new Error('Usuario no encontrado')
    error.status = 404
    throw error
  }
  return sanitize(user)
}

export async function updateProfile(userId, data) {
  if (await isDbAvailable()) {
    const user = await userModel.updateProfile(userId, data)
    return sanitize(user)
  }

  const user = memoryStore.users.find((item) => item.id === userId)
  if (!user) {
    const error = new Error('Usuario no encontrado')
    error.status = 404
    throw error
  }

  Object.assign(user, data)
  return sanitize(user)
}