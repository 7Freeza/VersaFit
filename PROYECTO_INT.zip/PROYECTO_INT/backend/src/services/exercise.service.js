/**
 * ARCHIVO: backend/src/services/exercise.service.js
 * CAPA: Servicios (lógica de negocio)
 * CONECTA CON:
 *   - Llamado por: exercise.controller.js
 *   - Usa: exercise.model.js, db.helper.js, memory.store.js
 * RESPONSABILIDAD: Listar rutinas y marcar sesión completada hoy.
 * ENDPOINTS / TABLAS / DATOS:
 *   - GET /api/exercise/routines, PATCH /api/exercise/sessions/:id/complete
 *   - Tablas rutinas / sesiones o memoryStore.routines[userId]
 * NOTAS: En memoria marca completado=true; en BD inserta sesión si no existe hoy.
 */

import * as exerciseModel from '../models/exercise.model.js'
import { isDbAvailable } from './db.helper.js'
import { memoryStore } from './memory.store.js'

export async function listRoutines(userId) {
  if (await isDbAvailable()) {
    return exerciseModel.getRoutinesByUser(userId)
  }
  return memoryStore.routines[userId] || []
}

export async function completeRoutine(userId, routineId) {
  if (await isDbAvailable()) {
    return exerciseModel.completeRoutineToday(userId, routineId)
  }

  const routines = memoryStore.routines[userId] || []
  const routine = routines.find((item) => item.id === Number(routineId))
  if (!routine) {
    const error = new Error('Rutina no encontrada')
    error.status = 404
    throw error
  }
  routine.completado = true
  return { completado: true }
}