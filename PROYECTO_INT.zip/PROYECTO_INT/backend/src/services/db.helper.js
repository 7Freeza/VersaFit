/**
 * ARCHIVO: backend/src/services/db.helper.js
 * CAPA: Servicios (utilidad)
 * CONECTA CON:
 *   - Importa: pool desde models/db.js
 *   - Usado por: todos los *.service.js (auth, users, progress, productivity, nutrition, exercise)
 * RESPONSABILIDAD: Detectar si MySQL está disponible (SELECT 1) y cachear resultado.
 * ENDPOINTS / TABLAS / DATOS: Sin tablas; prueba de conectividad al pool.
 * NOTAS: Resultado cacheado en memoria (dbAvailable). Si falla, servicios usan memory.store.
 */

import { pool } from '../models/db.js'

let dbAvailable = null

export async function isDbAvailable() {
  if (dbAvailable !== null) return dbAvailable
  try {
    await pool.query('SELECT 1')
    dbAvailable = true
  } catch {
    dbAvailable = false
    console.warn('MySQL no disponible — usando datos en memoria para desarrollo')
  }
  return dbAvailable
}