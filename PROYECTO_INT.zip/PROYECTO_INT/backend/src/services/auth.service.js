/**
 * ARCHIVO: backend/src/services/auth.service.js
 * CAPA: Servicios (lógica de negocio)
 * CONECTA CON:
 *   - Llamado por: auth.controller.js
 *   - Usa: user.model.js, db.helper.js, memory.store.js
 * RESPONSABILIDAD: Login, registro, logout; hash bcrypt y emisión JWT (8h).
 * ENDPOINTS / TABLAS / DATOS:
 *   - Tabla usuarios vía user.model; fallback memoryStore.users
 *   - Credenciales demo en memoria: demo@proyecto.com / demo123
 * NOTAS: Si MySQL no está, usa memoria. logout es stateless (solo { ok: true }).
 */

import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import * as userModel from '../models/user.model.js'
import { isDbAvailable } from './db.helper.js'
import { memoryStore } from './memory.store.js'

function signToken(user) {
  return jwt.sign(
    { id: user.id, email: user.email, nombre: user.nombre },
    process.env.JWT_SECRET || 'dev_secret',
    { expiresIn: '8h' },
  )
}

function sanitizeUser(user) {
  return {
    id: user.id,
    nombre: user.nombre,
    email: user.email,
    peso: user.peso ?? null,
    altura: user.altura ?? null,
    objetivo: user.objetivo ?? 'mantener',
  }
}

export async function login({ email, password }) {
  const useDb = await isDbAvailable()
  let user = null

  if (useDb) {
    user = await userModel.findByEmail(email)
  } else {
    user = memoryStore.users.find((item) => item.email === email)
  }

  if (!user) {
    const error = new Error('Credenciales inválidas')
    error.status = 401
    throw error
  }

  const valid = await bcrypt.compare(password, user.password_hash)
  if (!valid) {
    const error = new Error('Credenciales inválidas')
    error.status = 401
    throw error
  }

  return {
    token: signToken(user),
    user: sanitizeUser(user),
  }
}

export async function register({ nombre, email, password }) {
  const useDb = await isDbAvailable()
  const passwordHash = await bcrypt.hash(password, 10)

  if (useDb) {
    const existing = await userModel.findByEmail(email)
    if (existing) {
      const error = new Error('El correo ya está registrado')
      error.status = 409
      throw error
    }
    const user = await userModel.createUser({ nombre, email, passwordHash })
    return { token: signToken(user), user: sanitizeUser(user) }
  }

  const exists = memoryStore.users.some((item) => item.email === email)
  if (exists) {
    const error = new Error('El correo ya está registrado')
    error.status = 409
    throw error
  }

  const user = {
    id: memoryStore.users.length + 1,
    nombre,
    email,
    password_hash: passwordHash,
    peso: null,
    altura: null,
    objetivo: 'mantener',
  }
  memoryStore.users.push(user)
  memoryStore.habits[user.id] = []
  memoryStore.meals[user.id] = []
  memoryStore.routines[user.id] = []

  return { token: signToken(user), user: sanitizeUser(user) }
}

export async function logout() {
  return { ok: true }
}