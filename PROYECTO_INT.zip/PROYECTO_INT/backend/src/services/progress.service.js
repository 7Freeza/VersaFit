/**
 * ARCHIVO: backend/src/services/progress.service.js
 * CAPA: Servicios (lógica de negocio)
 * CONECTA CON:
 *   - Llamado por: progress.controller.js
 *   - Usa: progress.model.js, db.helper.js, memory.store.js (habits, meals, routines)
 * RESPONSABILIDAD: Resumen de progreso general y por módulo (productividad, nutrición, ejercicio).
 * ENDPOINTS / TABLAS / DATOS:
 *   - GET /api/progress → general, productividad, nutricion, ejercicio, messages
 *   - BD: progreso_modulo; memoria: cálculo desde hábitos/comidas/rutinas del día
 * NOTAS: Sin filas en BD, usa calcFromMemory(). Nutrición en memoria: min(100, comidas*25).
 */

import * as progressModel from '../models/progress.model.js'
import { isDbAvailable } from './db.helper.js'
import { memoryStore } from './memory.store.js'

function calcFromMemory(userId) {
  const habits = memoryStore.habits[userId] || []
  const meals = memoryStore.meals[userId] || []
  const routines = memoryStore.routines[userId] || []

  const productividad = habits.length
    ? Math.round((habits.filter((h) => h.completado).length / habits.length) * 100)
    : 0
  const nutricion = Math.min(100, meals.length * 25)
  const ejercicio = routines.length
    ? Math.round((routines.filter((r) => r.completado).length / routines.length) * 100)
    : 0
  const general = Math.round((productividad + nutricion + ejercicio) / 3)

  return {
    general,
    productividad,
    nutricion,
    ejercicio,
    messages: {
      general: general >= 70 ? '¡Excelente constancia!' : 'Sigue construyendo hábitos',
      productividad: `${habits.filter((h) => h.completado).length}/${habits.length || 0} hábitos hoy`,
      nutricion: `${meals.length} comidas registradas hoy`,
      ejercicio: `${routines.filter((r) => r.completado).length}/${routines.length || 0} rutinas completadas`,
    },
  }
}

export async function getOverview(userId) {
  const useDb = await isDbAvailable()

  if (!useDb) {
    return calcFromMemory(userId)
  }

  const rows = await progressModel.getModuleProgress(userId)
  if (!rows.length) {
    return calcFromMemory(userId)
  }

  const map = Object.fromEntries(rows.map((row) => [row.modulo, row]))
  const productividad = map.productividad?.porcentaje ?? 0
  const nutricion = map.nutricion?.porcentaje ?? 0
  const ejercicio = map.ejercicio?.porcentaje ?? 0

  return {
    general: Math.round((productividad + nutricion + ejercicio) / 3),
    productividad,
    nutricion,
    ejercicio,
    messages: {
      general: map.general?.mensaje || 'Progreso calculado desde la base de datos',
      productividad: map.productividad?.mensaje || '',
      nutricion: map.nutricion?.mensaje || '',
      ejercicio: map.ejercicio?.mensaje || '',
    },
  }
}