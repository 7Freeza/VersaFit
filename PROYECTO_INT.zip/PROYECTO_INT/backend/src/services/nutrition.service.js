/**
 * ARCHIVO: backend/src/services/nutrition.service.js
 * CAPA: Servicios (lógica de negocio)
 * CONECTA CON:
 *   - Llamado por: nutrition.controller.js
 *   - Usa: nutrition.model.js, db.helper.js, memory.store.js
 * RESPONSABILIDAD: Plan del día (comidas registradas) y alta de nuevas comidas.
 * ENDPOINTS / TABLAS / DATOS:
 *   - GET /api/nutrition/plan, POST /api/nutrition/meals { nombre, calorias? }
 *   - Tabla comidas_registro o memoryStore.meals[userId]
 * NOTAS: calorias opcional en memoria; en BD se inserta lo recibido.
 */

import * as nutritionModel from '../models/nutrition.model.js'
import { isDbAvailable } from './db.helper.js'
import { memoryStore } from './memory.store.js'

export async function getPlan(userId) {
  if (await isDbAvailable()) {
    return nutritionModel.getTodayMeals(userId)
  }
  return memoryStore.meals[userId] || []
}

export async function addMeal(userId, data) {
  if (await isDbAvailable()) {
    return nutritionModel.registerMeal(userId, data)
  }

  const meal = {
    id: memoryStore.nextMealId++,
    nombre: data.nombre,
    calorias: data.calorias,
  }
  if (!memoryStore.meals[userId]) memoryStore.meals[userId] = []
  memoryStore.meals[userId].push(meal)
  return meal
}