/**
 * ARCHIVO: backend/src/models/db.js
 * CAPA: Modelos (acceso a datos)
 * CONECTA CON:
 *   - Reexporta: pool desde src/config/db.config.js
 *   - Importado por: todos los *.model.js y src/services/db.helper.js
 * RESPONSABILIDAD: Punto único de importación del pool MySQL para la capa de modelos.
 * ENDPOINTS / TABLAS / DATOS: No ejecuta queries; solo expone pool.
 * NOTAS: Evita acoplar modelos directamente a db.config; facilita tests y cambios de config.
 */

export { pool } from '../config/db.config.js'