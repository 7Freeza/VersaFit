/**
 * ARCHIVO: backend/src/models/user.model.js
 * CAPA: Modelos (acceso a datos)
 * CONECTA CON:
 *   - Importa: ./db.js (pool)
 *   - Llamado por: auth.service.js, users.service.js
 * RESPONSABILIDAD: CRUD de lectura/escritura sobre la tabla usuarios.
 * ENDPOINTS / TABLAS / DATOS:
 *   - Tabla: usuarios (id, nombre, email, password_hash, peso, altura, objetivo)
 *   - findByEmail, findById, createUser, updateProfile
 * NOTAS: password_hash solo se devuelve en findByEmail (login). Perfil público sin hash.
 */

import { pool } from './db.js'

export async function findByEmail(email) {
  const [rows] = await pool.query(
    'SELECT id, nombre, email, password_hash, peso, altura, objetivo FROM usuarios WHERE email = ? LIMIT 1',
    [email],
  )
  return rows[0] || null
}

export async function findById(id) {
  const [rows] = await pool.query(
    'SELECT id, nombre, email, peso, altura, objetivo FROM usuarios WHERE id = ? LIMIT 1',
    [id],
  )
  return rows[0] || null
}

export async function createUser({ nombre, email, passwordHash }) {
  const [result] = await pool.query(
    'INSERT INTO usuarios (nombre, email, password_hash) VALUES (?, ?, ?)',
    [nombre, email, passwordHash],
  )
  return findById(result.insertId)
}

export async function updateProfile(id, data) {
  await pool.query(
    'UPDATE usuarios SET nombre = ?, email = ?, peso = ?, altura = ?, objetivo = ? WHERE id = ?',
    [data.nombre, data.email, data.peso, data.altura, data.objetivo, id],
  )
  return findById(id)
}