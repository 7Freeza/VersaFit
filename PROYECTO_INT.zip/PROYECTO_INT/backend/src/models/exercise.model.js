/**
 * ARCHIVO: backend/src/models/exercise.model.js
 * CAPA: Modelos (acceso a datos)
 * CONECTA CON:
 *   - Importa: ./db.js (pool)
 *   - Llamado por: exercise.service.js
 * RESPONSABILIDAD: Rutinas de ejercicio y sesiones completadas hoy.
 * ENDPOINTS / TABLAS / DATOS:
 *   - Tablas: rutinas, sesiones
 *   - getRoutinesByUser, completeRoutineToday (idempotente si ya existe sesión hoy)
 * NOTAS: completado = 1 si hay sesión con fecha CURDATE() para esa rutina.
 */

import { pool } from './db.js'

export async function getRoutinesByUser(userId) {
  const [rows] = await pool.query(
    `SELECT r.id, r.nombre, r.descripcion,
            CASE WHEN s.id IS NOT NULL THEN 1 ELSE 0 END AS completado
     FROM rutinas r
     LEFT JOIN sesiones s
       ON s.rutina_id = r.id AND s.usuario_id = r.usuario_id AND s.fecha = CURDATE()
     WHERE r.usuario_id = ?
     ORDER BY r.id`,
    [userId],
  )
  return rows
}

export async function completeRoutineToday(userId, routineId) {
  const [existing] = await pool.query(
    'SELECT id FROM sesiones WHERE rutina_id = ? AND usuario_id = ? AND fecha = CURDATE()',
    [routineId, userId],
  )

  if (existing.length) {
    return { completado: true }
  }

  await pool.query(
    'INSERT INTO sesiones (rutina_id, usuario_id, fecha) VALUES (?, ?, CURDATE())',
    [routineId, userId],
  )
  return { completado: true }
}