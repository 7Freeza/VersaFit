/**
 * ARCHIVO: backend/src/models/productivity.model.js
 * CAPA: Modelos (acceso a datos)
 * CONECTA CON:
 *   - Importa: ./db.js (pool)
 *   - Llamado por: productivity.service.js
 * RESPONSABILIDAD: Hábitos diarios y su registro de completado (toggle por fecha).
 * ENDPOINTS / TABLAS / DATOS:
 *   - Tablas: habitos, habitos_registro
 *   - getHabitsByUser, createHabit, toggleHabitToday (fecha = CURDATE())
 * NOTAS: completado se deriva de LEFT JOIN con habitos_registro del día actual.
 */

import { pool } from './db.js'

export async function getHabitsByUser(userId) {
  const [rows] = await pool.query(
    `SELECT h.id, h.titulo,
            CASE WHEN r.id IS NOT NULL THEN 1 ELSE 0 END AS completado
     FROM habitos h
     LEFT JOIN habitos_registro r
       ON r.habito_id = h.id AND r.usuario_id = h.usuario_id AND r.fecha = CURDATE()
     WHERE h.usuario_id = ?
     ORDER BY h.id`,
    [userId],
  )
  return rows
}

export async function createHabit(userId, titulo) {
  const [result] = await pool.query(
    'INSERT INTO habitos (usuario_id, titulo) VALUES (?, ?)',
    [userId, titulo],
  )
  return { id: result.insertId, titulo, completado: 0 }
}

export async function toggleHabitToday(userId, habitId) {
  const [existing] = await pool.query(
    'SELECT id FROM habitos_registro WHERE habito_id = ? AND usuario_id = ? AND fecha = CURDATE()',
    [habitId, userId],
  )

  if (existing.length) {
    await pool.query('DELETE FROM habitos_registro WHERE id = ?', [existing[0].id])
    return { completado: false }
  }

  await pool.query(
    'INSERT INTO habitos_registro (habito_id, usuario_id, fecha) VALUES (?, ?, CURDATE())',
    [habitId, userId],
  )
  return { completado: true }
}