/**
 * ARCHIVO: backend/src/models/goal.model.js
 * CAPA: Modelos (acceso a datos)
 * CONECTA CON:
 *   - Importa: ./db.js (pool)
 *   - Exporta: getGoalsByUser (sin servicio/ruta asociada aún)
 * RESPONSABILIDAD: Consultar metas del usuario en la tabla metas.
 * ENDPOINTS / TABLAS / DATOS:
 *   - Tabla: metas (id, usuario_id, tipo, meta_valor, progreso_valor)
 * NOTAS: Modelo preparado para futura funcionalidad de objetivos; no usado en controllers actuales.
 */

import { pool } from './db.js'

export async function getGoalsByUser(userId) {
  const [rows] = await pool.query(
    'SELECT id, tipo, meta_valor, progreso_valor FROM metas WHERE usuario_id = ?',
    [userId],
  )
  return rows
}