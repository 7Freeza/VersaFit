/**
 * ARCHIVO: backend/src/models/nutrition.model.js
 * CAPA: Modelos (acceso a datos)
 * CONECTA CON:
 *   - Importa: ./db.js (pool)
 *   - Llamado por: nutrition.service.js
 * RESPONSABILIDAD: Comidas registradas del día actual por usuario.
 * ENDPOINTS / TABLAS / DATOS:
 *   - Tabla: comidas_registro (usuario_id, nombre, calorias, fecha)
 *   - getTodayMeals, registerMeal (siempre fecha = hoy)
 * NOTAS: El "plan" del API es la lista de comidas del día, no un menú predefinido.
 */

import { pool } from './db.js'

export async function getTodayMeals(userId) {
  const [rows] = await pool.query(
    `SELECT id, nombre, calorias
     FROM comidas_registro
     WHERE usuario_id = ? AND fecha = CURDATE()
     ORDER BY id`,
    [userId],
  )
  return rows
}

export async function registerMeal(userId, { nombre, calorias }) {
  const [result] = await pool.query(
    'INSERT INTO comidas_registro (usuario_id, nombre, calorias, fecha) VALUES (?, ?, ?, CURDATE())',
    [userId, nombre, calorias],
  )
  return { id: result.insertId, nombre, calorias }
}