/**
 * ARCHIVO: backend/src/models/progress.model.js
 * CAPA: Modelos (acceso a datos)
 * CONECTA CON:
 *   - Importa: ./db.js (pool)
 *   - Llamado por: progress.service.js
 * RESPONSABILIDAD: Obtener porcentajes y mensajes de progreso por módulo.
 * ENDPOINTS / TABLAS / DATOS:
 *   - Tabla: progreso_modulo (usuario_id, modulo, porcentaje, mensaje)
 *   - Módulos típicos: productividad, nutricion, ejercicio, general
 * NOTAS: Si no hay filas, progress.service recalcula desde memoria u otros datos.
 */

import { pool } from './db.js'

export async function getModuleProgress(userId) {
  const [rows] = await pool.query(
    `SELECT modulo, porcentaje, mensaje
     FROM progreso_modulo
     WHERE usuario_id = ?`,
    [userId],
  )
  return rows
}