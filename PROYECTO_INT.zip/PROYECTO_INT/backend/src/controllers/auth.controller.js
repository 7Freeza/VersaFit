/**
 * ARCHIVO: backend/src/controllers/auth.controller.js
 * CAPA: Controladores (HTTP)
 * CONECTA CON:
 *   - Llamado por: auth.routes.js
 *   - Llama a: auth.service.js
 * RESPONSABILIDAD: Adaptar req/res Express a login, register y logout.
 * ENDPOINTS / TABLAS / DATOS:
 *   - POST /api/auth/login → { token, user }
 *   - POST /api/auth/register → 201 { token, user }
 *   - POST /api/auth/logout → { ok: true }
 * NOTAS: Errores se delegan a next(error) → handler global en server.js.
 */

import * as authService from '../services/auth.service.js'

export async function login(req, res, next) {
  try {
    const result = await authService.login(req.body)
    res.json(result)
  } catch (error) {
    next(error)
  }
}

export async function register(req, res, next) {
  try {
    const result = await authService.register(req.body)
    res.status(201).json(result)
  } catch (error) {
    next(error)
  }
}

export async function logout(_req, res, next) {
  try {
    const result = await authService.logout()
    res.json(result)
  } catch (error) {
    next(error)
  }
}