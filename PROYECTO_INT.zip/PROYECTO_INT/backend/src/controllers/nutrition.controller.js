/**
 * ARCHIVO: backend/src/controllers/nutrition.controller.js
 * CAPA: Controladores (HTTP)
 * CONECTA CON:
 *   - Llamado por: nutrition.routes.js (authMiddleware)
 *   - Llama a: nutrition.service.js
 * RESPONSABILIDAD: Plan nutricional del día y registro de comidas.
 * ENDPOINTS / TABLAS / DATOS:
 *   - GET /api/nutrition/plan → array de comidas hoy
 *   - POST /api/nutrition/meals { nombre, calorias? } → 201
 * NOTAS: registerMeal valida solo 'nombre' en ruta; calorias opcional.
 */

import * as nutritionService from '../services/nutrition.service.js'

export async function getPlan(req, res, next) {
  try {
    const plan = await nutritionService.getPlan(req.user.id)
    res.json(plan)
  } catch (error) {
    next(error)
  }
}

export async function registerMeal(req, res, next) {
  try {
    const meal = await nutritionService.addMeal(req.user.id, req.body)
    res.status(201).json(meal)
  } catch (error) {
    next(error)
  }
}