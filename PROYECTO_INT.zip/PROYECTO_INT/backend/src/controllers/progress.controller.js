/**
 * ARCHIVO: backend/src/controllers/progress.controller.js
 * CAPA: Controladores (HTTP)
 * CONECTA CON:
 *   - Llamado por: progress.routes.js (authMiddleware)
 *   - Llama a: progress.service.js
 * RESPONSABILIDAD: Devolver vista general de progreso del usuario autenticado.
 * ENDPOINTS / TABLAS / DATOS:
 *   - GET /api/progress → { general, productividad, nutricion, ejercicio, messages }
 * NOTAS: Un solo handler getProgress; agrega métricas de los tres módulos.
 */

import * as progressService from '../services/progress.service.js'

export async function getProgress(req, res, next) {
  try {
    const data = await progressService.getOverview(req.user.id)
    res.json(data)
  } catch (error) {
    next(error)
  }
}