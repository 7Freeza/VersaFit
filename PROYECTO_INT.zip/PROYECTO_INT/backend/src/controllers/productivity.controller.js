/**
 * ARCHIVO: backend/src/controllers/productivity.controller.js
 * CAPA: Controladores (HTTP)
 * CONECTA CON:
 *   - Llamado por: productivity.routes.js (authMiddleware)
 *   - Llama a: productivity.service.js
 * RESPONSABILIDAD: CRUD de hábitos: listar, crear y toggle completado.
 * ENDPOINTS / TABLAS / DATOS:
 *   - GET /api/productivity/habits
 *   - POST /api/productivity/habits { titulo }
 *   - PATCH /api/productivity/habits/:id/toggle
 * NOTAS: :id es habitId. createHabit lee req.body.titulo.
 */

import * as productivityService from '../services/productivity.service.js'

export async function listHabits(req, res, next) {
  try {
    const habits = await productivityService.listHabits(req.user.id)
    res.json(habits)
  } catch (error) {
    next(error)
  }
}

export async function createHabit(req, res, next) {
  try {
    const habit = await productivityService.addHabit(req.user.id, req.body.titulo)
    res.status(201).json(habit)
  } catch (error) {
    next(error)
  }
}

export async function toggleHabit(req, res, next) {
  try {
    const result = await productivityService.toggleHabit(req.user.id, req.params.id)
    res.json(result)
  } catch (error) {
    next(error)
  }
}