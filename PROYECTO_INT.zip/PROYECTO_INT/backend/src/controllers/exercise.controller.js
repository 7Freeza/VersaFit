/**
 * ARCHIVO: backend/src/controllers/exercise.controller.js
 * CAPA: Controladores (HTTP)
 * CONECTA CON:
 *   - Llamado por: exercise.routes.js (authMiddleware)
 *   - Llama a: exercise.service.js
 * RESPONSABILIDAD: Rutinas de ejercicio y completar sesión del día.
 * ENDPOINTS / TABLAS / DATOS:
 *   - GET /api/exercise/routines
 *   - PATCH /api/exercise/sessions/:id/complete (:id = routineId)
 * NOTAS: Nombre completeSession pero :id referencia rutina, no fila de sesiones.
 */

import * as exerciseService from '../services/exercise.service.js'

export async function listRoutines(req, res, next) {
  try {
    const routines = await exerciseService.listRoutines(req.user.id)
    res.json(routines)
  } catch (error) {
    next(error)
  }
}

export async function completeSession(req, res, next) {
  try {
    const result = await exerciseService.completeRoutine(req.user.id, req.params.id)
    res.json(result)
  } catch (error) {
    next(error)
  }
}