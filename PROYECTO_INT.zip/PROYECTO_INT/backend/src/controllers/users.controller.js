/**
 * ARCHIVO: backend/src/controllers/users.controller.js
 * CAPA: Controladores (HTTP)
 * CONECTA CON:
 *   - Llamado por: users.routes.js (requiere authMiddleware)
 *   - Llama a: users.service.js; usa req.user.id del JWT
 * RESPONSABILIDAD: Perfil del usuario autenticado (lectura y actualización).
 * ENDPOINTS / TABLAS / DATOS:
 *   - GET /api/users/profile
 *   - PUT /api/users/profile { nombre, email, peso, altura, objetivo }
 * NOTAS: No valida body con validateBody; campos vienen directo de req.body.
 */

import * as usersService from '../services/users.service.js'

export async function getProfile(req, res, next) {
  try {
    const profile = await usersService.getProfile(req.user.id)
    res.json(profile)
  } catch (error) {
    next(error)
  }
}

export async function updateProfile(req, res, next) {
  try {
    const profile = await usersService.updateProfile(req.user.id, req.body)
    res.json(profile)
  } catch (error) {
    next(error)
  }
}